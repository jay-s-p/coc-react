import logo from './logo.png';
import './App.css';
import Box from './Box';
import data from './data.json'
import dataAttendance from './dataAttendance.json'

function App() {
  return (
    <div className="App">      
      <p><img src={logo} style={{width:"100px"}} /></p>
        {
          data.map((subdata, j) => {                                                
            // Return the element. Also pass key     
            return (
              <>
              <div className="col">
                {
                    subdata.schedule.map((item, i) => {                                                
                      // Return the element. Also pass key     
                      return (<Box attendance={dataAttendance[j].schedule[i].attendance} subject={item.subject} resource={item.resource} faculty={item.faculty} bgColor={item.backgroundColor} subjectColor={item.subjectColor}/>) 
                    })
                } 
                </div>
              </> 
            ) 
          })        

        }              
    </div>
  );
}

export default App;
