function Box(props){
    return (
      <>
      <div className="box" style={{backgroundColor:props.bgColor}}>
          {
            props.attendance!='a' ? <><span style={{backgroundColor:"GREEN",color:"white"}}>{props.attendance}</span></> : <><span style={{backgroundColor:"RED",color:"white"}}>{props.attendance}</span></>                        
          }
          <p style={{color:props.subjectColor}}>{props.subject}</p>
          <span>{props.resource}</span><span className="right">{props.faculty}</span>
      </div>
      </>
    );
}

export default Box;